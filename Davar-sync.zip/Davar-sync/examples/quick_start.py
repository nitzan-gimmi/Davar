import json, os

# Quick-start example expecting data/roots/כ-ת-ב.json inside Davar repo.
file_path = os.path.join('data', 'roots', 'כ-ת-ב.json')
if not os.path.exists(file_path):
    print('File not found:', file_path)
else:
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    # defensive navigation
    try:
        future_3ms = data['root_family']['verbs'][0]['tenses']['future']['singular']['3m']
        print('Sample:', future_3ms)
    except Exception as e:
        print('Could not extract example:', e)
