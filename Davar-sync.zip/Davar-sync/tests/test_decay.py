from src.decay_model import computedecay_score

def test_decay_defaults():
    score = computedecay_score({'root': 'פעל', 'tense': 'past', 'binyan': 'פיעל'})
    assert score == 1.3
