from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_tokenize_endpoint():
    r = client.post('/tokenize', json={'text': 'שלום עולם'})
    assert r.status_code == 200
    assert 'tokens' in r.json()

def test_decay_endpoint():
    r = client.post('/decay', json={'root': 'פעל', 'tense': 'past', 'binyan': 'פיעל'})
    assert r.status_code == 200
    assert 'decay_score' in r.json()
