from src.tokenizer import tokenize

def test_tokenize_simple():
    assert tokenize('שלום עולם') == ['שלום', 'עולם']
