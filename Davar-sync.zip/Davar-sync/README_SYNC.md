# Davar — Sync helper package (skeleton)
This archive contains helper files and skeleton code to sync into the `Davar` repository.
Author: נִצן בנין (templates by Jimmy AI)
