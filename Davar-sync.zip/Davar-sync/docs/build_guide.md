# Build & Sync Guide (Davar)

This guide explains how to integrate the helper skeleton into the Davar repo.

1. Clone your repo:
   `git clone https://github.com/nitzan-gimmi/Davar.git && cd Davar`
2. Create branch:
   `git checkout -b sync/build`
3. Copy the files from this skeleton into the repository root (preserve existing files).
4. Commit & push:
   `git add . && git commit -m "Add sync skeleton (tests, API, CI) [Jimmy]" && git push origin sync/build`
5. Open a Pull Request from `sync/build` to `main` and request review.

Keep changes additive: do not overwrite existing data/roots files. Add tests and docs in parallel.
