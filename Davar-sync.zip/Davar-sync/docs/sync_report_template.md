# sync_report.md (template)
Fill this file with the scanning results: list of files found, missing items, and actions performed.
