import subprocess, sys
print('Running pytest...')
rc = subprocess.call([sys.executable, '-m', 'pytest', 'tests', '-q'])
raise SystemExit(rc)
