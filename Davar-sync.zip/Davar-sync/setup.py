from setuptools import setup, find_packages

setup(
    name="davar_hfbt_helpers",
    version="0.1.0",
    author="נִצן בנין",
    author_email="Nitzan.banin@gmail.com",
    description="Helper skeleton files for Davar sync/CI/tests",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "fastapi",
        "uvicorn",
        "pytest"
    ],
)
