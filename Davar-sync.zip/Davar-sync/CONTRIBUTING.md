# Contributing to Davar

Thanks for wanting to help! Small, focused PRs are best.
Guidelines:
- Create an issue before large changes.
- Work on a feature branch: `git checkout -b feature/your-name-shortdesc`
- Include tests for code changes (pytest).
- Keep modifications additive; don't remove others' data or text.
- Sign commits with your name and role in the commit message.

Example commit message:
`feat: add tokenize unit test (by Alice)`

