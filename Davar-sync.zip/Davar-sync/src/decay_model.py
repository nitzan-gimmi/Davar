# Simple placeholder for decay scoring
def computedecay_score(params: dict) -> float:
    # params expected: {'root': 'פעל', 'tense': 'past', 'binyan': 'פיעל'}
    base = 1.0
    binyan = params.get('binyan', '')
    if binyan == 'פיעל':
        return 1.3
    return base
