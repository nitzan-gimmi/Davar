# Tokenizer stub
def tokenize(text: str):
    return text.split()
