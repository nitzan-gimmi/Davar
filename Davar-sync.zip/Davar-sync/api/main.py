from fastapi import FastAPI
from pydantic import BaseModel
from src.tokenizer import tokenize as tokenize_fn
from src.decay_model import computedecay_score

app = FastAPI(title='Davar API', version='0.1.0')

class TextInput(BaseModel):
    text: str

class DecayInput(BaseModel):
    root: str
    tense: str
    binyan: str

@app.post('/tokenize')
def tokenize_text(input: TextInput):
    return {'tokens': tokenize_fn(input.text)}

@app.post('/decay')
def decay_score(input: DecayInput):
    return {'decay_score': computedecay_score(input.dict())}
